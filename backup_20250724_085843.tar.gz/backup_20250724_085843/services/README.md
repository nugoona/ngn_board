services
├── cafe24_service.py
├── catalog_sidebar_service.py
├── data_service.py
├── Fetch_Adset_Summary.py
├── filter_service.py
├── ga4_source_summary.py
├── __init__.py
├── insert_performance_summary.py
├── meta_ads_insight.py
├── meta_ads_preview.py
├── meta_ads_service.py
├── meta_ads_slide_collection.py
├── meta_demo_handler.py
├── meta_demo_service.py
├── monthly_net_sales_visitors.py
├── performance_summary.py
├── platform_sales_summary.py
├── product_sales_ratio.py
├── README.md
├── test_meta_ads_insight.py
└── viewitem_summary.py

1 directory, 21 files
