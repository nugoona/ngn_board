.
├── ads_page.html
├── components
│   ├── cafe24_product_sales_table.html
│   ├── cafe24_sales_table.html
│   ├── catalog_sidebar.html
│   ├── filters.html
│   ├── ga4_source_summary_table.html
│   ├── meta_ads_adset_summary_by_type_table.html
│   ├── meta_ads_insight_table.html
│   ├── meta_ads_preview_cards.html
│   ├── meta_ads_slide_collection_table.html
│   ├── meta_ads_table.html
│   ├── monthly_net_sales_visitors_chart.html
│   ├── performance_summary_table.html
│   ├── platform_sales_monthly.html
│   ├── platform_sales_ratio.html
│   ├── platform_sales_summary_table.html
│   ├── product_sales_ratio.html
│   └── viewitem_summary_table.html
├── delete_info.html
├── index.html
├── login.html
├── meta_demo.html
├── privacy.html
├── README.md
└── terms.html

2 directories, 25 files
